<?php

function db(){
    include "db.php";
}

function HeaderTop(){
    include "include/header.php";
}

function Sidebar(){
    include "include/sidebar.php";
}

function Footer(){
    include "include/footer.php";
}

