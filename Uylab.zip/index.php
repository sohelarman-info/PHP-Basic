<?php 
include_once "function.php";
include_once "db.php";
HeaderTop();
Sidebar();
?>


<!-- 12 column body start here -->


<div>Hello</div>


<!-- 12 column body end here -->














<?php Footer() ?>




